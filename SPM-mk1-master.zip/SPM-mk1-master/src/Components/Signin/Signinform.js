import React, { Component, useState} from 'react'
import Button from '@material-ui/core/Button';
import { FormH1,  Form, EmailRow} from './SigninElements.js';
import axios from 'axios';
import { Link } from 'react-router-dom';

class FormInput extends Component {
    

    render(){
        return (<>
                    <Form >
                            <FormH1>Create a group Join a group or sign in </FormH1>

                            <EmailRow>
                                <Button component={Link} to="/createGroup" style={{ margin: 8, width: '100%' }} variant="outlined">Create User</Button>
                                <Button component={Link} to="/joinGroup" style={{ margin: 8, width: '100%' }} variant="outlined">Create group</Button>
                                <Button component={Link} to="/Signin" style={{ margin: 8, width: '100%' }} variant="outlined">Sign in</Button>
                                <Button component={Link} to="/home" style={{ margin: 8, width: '100%' }} variant="outlined">Home</Button>
                            </EmailRow>
                    </Form>
                </>
            )
    }
}

export default FormInput;