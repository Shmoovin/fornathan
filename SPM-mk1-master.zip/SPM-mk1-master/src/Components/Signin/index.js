import React from 'react';
import {Container, FormWrap, TextWrapper,  FormContent, AboutText,FormH1 } from './SigninElements.js';
import FormInput from './Signinform.js';

const Signin = () => {

    return (
        <>
            <Container>
                <FormWrap>
                    <FormContent>
                        <TextWrapper>
                            <AboutText>
                            </AboutText> 
                        </TextWrapper>
                      <FormInput />
                    </FormContent>
                </FormWrap>
            </Container>

        </>

    );
};

export default Signin;