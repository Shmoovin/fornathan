import React ,{useState} from 'react';
import {Container,FormWrap, Form, Text, Header} from './JoinformElements.js'
import Button from '@material-ui/core/Button';
import { TextField } from '@material-ui/core';
import { Link } from 'react-router-dom';

const Joinform = () => {
    
    const [state,setStates] = 
    useState(
    {
    gName:"",
    gPassword:""
    });

    
    const submitHandler = (e) =>{
        e.preventDefault()
        console.log(state)
        fetch('http://localhost:5000/api/createGroup',{method: 'POST',headers : {
            'Content-Type':'application/json'
      }, body: JSON.stringify(state)})
        .then((response) => {console.log(response.json())})
        .catch((error)=>{console.error('Error:', error);});
    }
    return (
    <>
        <Container>
            <FormWrap>
                <Form onSubmit={submitHandler} action="#">
                    <Header>Input information</Header>
                    <Text>Input group Name </Text>
                    <TextField  id="filled-hidden-label-small"
                        defaultValue=""
                        variant="filled"
                        size="large"
                        type="text"
                        name="gName"
                        value={state.uEmail}
                        onChange={e => setStates({ ... state, gName: e.target.value})}/>
                    <Text>Input Group Password </Text>
                    <TextField  id="filled-hidden-label-small"
                        defaultValue=""
                        variant="filled"
                        size="large"
                        type="password"
                        name="gPassword"
                        value={state.uPassword}
                        onChange={e => setStates({ ... state, gPassword: e.target.value})}
                        />
                    <Button style={{ margin: 8, width: '100%' }} variant="outlined" type="submit" >Input</Button>
                    <Button component={Link} to="/" style={{ margin: 8, width: '100%' }} variant="outlined">Back</Button>
                </Form>
            </FormWrap>
        </Container>
    </>
    );
};

export default Joinform;