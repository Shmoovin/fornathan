import styled from 'styled-components';
import { Link } from 'react-router-dom';

export const Container = styled.div`
    min-height: 692px;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    top: 0;
    z-index: 0;
    overflow: hidden;
    background: #B1A6A4;
`;

export const FormWrap = styled.div`
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
`;


export const Form = styled.form`
    background: #FED8B5;
    max-width: 800px;
    height: 900px;
    width: 100%;
    z-index: 1;
    align-items: center;
    display: grid;
    margin: 0 auto;
    padding: 80px 32px;
    border-radius: 4px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.9);
    @media screen and (max-width: 480px) {
        padding: 32px 32px;
    }
`;


export const Text = styled.h1`
    text-align: left;
    margin-top: 24px;
    color: #3C403D;
    font-size: 20px;
`;

export const Header = styled.h1`
    text-align: center;
    margin-top: 24px;
    color: #3C403D;
    font-size: 20px;
`;