import React from 'react';
import Navbar from '../Components/Navbar';
import Signin from '../Components/Signin';
const Home = () => {

    return(
        <>
            <Signin />
        </>
    );
};

export default Home;