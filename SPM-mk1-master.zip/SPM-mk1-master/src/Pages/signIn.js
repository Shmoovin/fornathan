import React from 'react';
import SigninForm from '../Components/Signinform';

const Signon = () => {


    return(
        <>
            <SigninForm/>
        </>
    );
};

export default Signon ;