import React, {useState} from 'react';
import Joinform from '../Components/Joinform'

const Join = () => {


    return(
        <>
            <Joinform />
        </>
    );
};

export default Join;