import React, {useState} from 'react';
import Createform from '../Components/Createform'

const Create = () => {


    return(
        <>
            <Createform />
        </>
    );
};

export default Create;