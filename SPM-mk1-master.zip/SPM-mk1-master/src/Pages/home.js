import React, {useState} from 'react';
import Navbar from '../Components/Navbar';
import Tasklist from '../Components/Tasklist';

const Homepage = () => {

    return(
        <>
            <Navbar />
            <Tasklist />
        </>
    );
};

export default Homepage;