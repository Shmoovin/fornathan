import React from 'react';
import './App.css';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Home from './Pages/index.js';
import Signon from './Pages/signIn.js';
import Create from './Pages/createGroup.js';
import Homepage from './Pages/home.js';
import Join from './Pages/joinGroup';


function App() {
  return (
    <Router>
      <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/createGroup' element={<Create />} />
          <Route path='/Signin' element= {<Signon />}/>
          <Route path='/Home' element= {<Homepage />}/>
          <Route path='/joinGroup' element= {<Join />}/>
      </Routes>
    </Router>
  );
}

export default App;