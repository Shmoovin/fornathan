from nturl2path import url2pathname
from pickle import TRUE
from sqlite3 import Cursor
import time
from flask import Flask, jsonify, redirect, request, url_for
import requests  
from flask_mysqldb import MySQL
from flask_restful import Resource, reqparse, Api
from flask_cors import CORS


#flask app
app = Flask(__name__,static_folder='../build', static_url_path='/')
api = Api(app)

app.config['MYSQL_HOST'] = 'spm-mysql.cptlpd2j0jid.us-east-2.rds.amazonaws.com'
app.config['MYSQL_USER'] = 'teammate'
app.config['MYSQL_PASSWORD'] = 'R0llTh3D!cE'
app.config['MYSQL_DB'] = 'spm_dev'

db = MySQL(app)

CORS(app, origins="http://localhost:3000", allow_headers=[
    "Content-Type", "Authorization", "Access-Control-Allow-Credentials"],
    supports_credentials=True)

app.config["CORS_HEADERS"] = 'Content-Type'

@app.route('/time')
def get_current_time():
    return {'time': time.time()}

@app.route('/db')
def show_tables():
    cursor = db.connection.cursor()
    cursor.execute('''SHOW TABLES''')
    rv = cursor.fetchall()
    return str(rv)

@app.route('/db/chore')
def show_chore():
    cursor = db.connection.cursor()
    cursor.execute('''SHOW COLUMNS FROM CHORE''')
    rv = cursor.fetchall()
    return str(rv)

@app.route('/db/group')
def show_group():
    cursor = db.connection.cursor()
    cursor.execute('''SHOW COLUMNS FROM  `GROUP`''')
    rv = cursor.fetchall()
    return str(rv)

@app.route('/db/permission')
def show_permission():
    cursor = db.connection.cursor()
    cursor.execute('''SHOW COLUMNS FROM PERMISSION''')
    rv = cursor.fetchall()
    return str(rv)

@app.route('/db/task')
def show_task():
    cursor = db.connection.cursor()
    cursor.execute('''SHOW COLUMNS FROM CHORE''')
    rv = cursor.fetchall()
    return str(rv)

@app.route('/db/task_user')
def show_task_user():
    cursor = db.connection.cursor()
    cursor.execute('''SHOW COLUMNS FROM TASK_USER''')
    rv = cursor.fetchall()
    return str(rv)

@app.route('/db/user')
def show_user():
    cursor = db.connection.cursor()
    cursor.execute('''SELECT * FROM USER''')
    rv = cursor.fetchall()
    return str(rv)

@app.errorhandler(404)
def not_found(error):
    return app.send_static_file('index.html')

@app.route('/')
def index():
    return app.send_send_static_file('index.html')

#args for User creation
group_info_args = reqparse.RequestParser()

group_info_args.add_argument("fName",type=str,help = "first") 
group_info_args.add_argument("lName",type=str,help = "last") 
group_info_args.add_argument("uEmail",type=str,help = "email") 
group_info_args.add_argument("uPassword",type=str,help = "pass")  

Group = {}
#Handles User Creation
class UserCreate(Resource):
    

    def get(self):
        #args = user_info_args.parse_args()
        return Group

    def post(self):
        args = group_info_args.parse_args()
        Group['fName'] = args['fName']
        Group['lName'] = args['lName']
        Group['uEmail'] = args['uEmail']
        Group['uPassword'] = args['uPassword']

        cursor = db.connection.cursor()
        cursor.execute('''INSERT INTO `USER` (USER_FNAME, USER_LNAME, USER_EMAIL, USER_PSWD) VALUES(%s, %s, %s, %s)'''
                        , (args['fName'], args['lName'], args['uEmail'], args['uPassword']))
        db.connection.commit()
        cursor.close()
        return args
api.add_resource(UserCreate,'/api/createUser')


#args for Sign in
user_info_args = reqparse.RequestParser()

user_info_args.add_argument("uEmail",type=str)
user_info_args.add_argument("uPassword",type=str)
User = {} #stores most recent user sign in for dev purposes

#handles sign in
class SignIn(Resource):
    
    def get(self):
        return User['success']
    def post(self):
        args = user_info_args.parse_args()
        User["uEmail"] = args["uEmail"]
        User["uPassword"] =args["uPassword"]
        
        cursor = db.connection.cursor()
        query_result = cursor.execute('''SELECT * FROM `USER` WHERE USER_EMAIL = %s''', [User["uEmail"]])

        #checks if user record exists
        if query_result > 0:
            user_data = cursor.fetchone()
            login_password = user_data[4]

            if (login_password == User["uPassword"]):
                User['success'] = True
            else:
                User['success'] = False


        return args
api.add_resource(SignIn,'/api/SignIn')


#Group Creation Args
create_info_args = reqparse.RequestParser()
create_info_args.add_argument("gName",type=str)
create_info_args.add_argument("gPassword",type=str)
create = {}

#Handles Group Creation
class GroupCreate(Resource):
    def get(self):
        return create
    def post(self):
        args = create_info_args.parse_args()
        create["gName"] = args["gName"]
        create["gPassword"] =args["gPassword"]
        cursor = db.connection.cursor()
        cursor.execute('''INSERT INTO `GROUP` (GROUP_NAME, GROUP_PSWD) VALUES( %s, %s)'''
                        , (args["gName"], args["gPassword"]))
        db.connection.commit()
        cursor.close()

        return args

api.add_resource(GroupCreate,'/api/createGroup')

if __name__ == '__main__':
    app.run(debug=True)